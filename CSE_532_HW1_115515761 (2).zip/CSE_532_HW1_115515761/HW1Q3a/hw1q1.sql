/*OLAP CUBE QUERY*/
SELECT HOUR("TIME"), MONTH("DATE"), COUNT(*) AS collision_count
FROM CSE532.hw1_collision
WHERE "TIME" IS NOT NULL AND "DATE" IS NOT NULL
GROUP BY CUBE (HOUR("TIME"), MONTH("DATE"));


/*QUERY TO RETRIEVE : hour in the day (based on all days in the year) has the peak of collision*/
SELECT HOUR("TIME") AS hour_of_day, COUNT(*) AS collision_count
FROM CSE532.hw1_collision
WHERE "TIME" IS NOT NULL AND "DATE" IS NOT NULL
GROUP BY HOUR("TIME")
ORDER BY collision_count DESC
LIMIT 1;
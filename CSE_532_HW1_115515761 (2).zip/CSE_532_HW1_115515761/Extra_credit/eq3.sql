WITH TopLocations AS (
    SELECT
        latitude,
        longitude,
        zip_code,
        COUNT(*) AS collision_count
    FROM
        CSE532.hw1_collision_all_data
    WHERE
        latitude IS NOT NULL
        AND longitude IS NOT NULL
        AND zip_code IS NOT NULL
    GROUP BY
        latitude, longitude, zip_code
    ORDER BY
        collision_count DESC
    FETCH FIRST 10 ROWS ONLY
)
SELECT
    TL.latitude,
    TL.longitude,
    TL.zip_code,
    TL.collision_count
FROM
    TopLocations TL
GROUP BY
    TL.latitude, TL.longitude, TL.zip_code, TL.collision_count;

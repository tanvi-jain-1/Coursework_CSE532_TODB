CSE532-HW1
SUMMARY

3a.
Hour of Peak Collisions: 16th i.e 4PM and collision_count is 16,973

Query used to retrive the same : 
SELECT HOUR("TIME") AS hour_of_day, COUNT(*) AS collision_count
FROM CSE532.hw1_collision
WHERE "TIME" IS NOT NULL AND "DATE" IS NOT NULL
GROUP BY HOUR("TIME")
ORDER BY collision_count DESC
LIMIT 1;

3b.
The SQL query selects the top 10 populated ZIP codes and the top 10 ZIP codes with the most collisions and then joins the two results based on the ZIP code. 

3c.
To find zip codes for top 10 most dangerous locations:

ZIP_CODE    LATITUDE                 LONGITUDE               
----------- ------------------------ ------------------------

      10036   +4.07608220000000E+001   -7.39983200000000E+001
      11226   +4.07608220000000E+001   -7.39983200000000E+001

  11 record(s) selected.

Here, 10036 and 11226 have the same latitude and longitude.  It can be checked from https://www.gps-coordinates.net/ that 11226 is not correct and the correct zip code is 10036. Hence, it has been eliminated.

Thus, the following are the most dangerous zip codes:
10012
10018
10022
10036
10453
10459
10474
11201


Extra Credit:
q1.
Hour of Peak Collisions: 16th i.e 4PM (same as 3a) but collision_count is 146,399
CONCLUSION : Hour of Peak collision is same for both data.

Query used to retrive the same : 
SELECT HOUR("TIME") AS hour_of_day, COUNT(*) AS collision_count
FROM CSE532.hw1_collision_all_data
WHERE "TIME" IS NOT NULL AND "DATE" IS NOT NULL
GROUP BY HOUR("TIME")
ORDER BY collision_count DESC
LIMIT 1;

q2.
After indexing the query execution time is reduced.
When running query q2 on hw1_collision_all_data, there is a variation in the output.
Executing the query on the hw1_collision table produces a result consisting of 4 rows, while running the same query on the hw1_collision_all_data table yields a different result containing 3 rows.
CONCLUSION : Result obtained is different from 3b. In 3b-Output conatin 4 rows & Extracredit q2 contain 3 rows.


q3.
This query provides information about the top 10 latitude and longitude combinations with the highest collision counts and their corresponding ZIP codes. 
Result obtained is different from original.
Here, 11201 and 11420 have the same latitude and longitude.  It can be checked from https://www.gps-coordinates.net/ that 11420 is not correct and the correct zip code is 11201. Hence, it has been eliminated.

Thus, the following are the most dangerous zip codes:
11201	40.696033	-73.984530
11420	40.696033	-73.984530

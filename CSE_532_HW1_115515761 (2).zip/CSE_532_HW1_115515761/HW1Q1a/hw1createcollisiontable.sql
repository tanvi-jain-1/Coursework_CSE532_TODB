create table CSE532.hw1_collision(
    date DATE, time TIME,
    zip_code VARCHAR(10),
    latitude DECIMAL(10,6),
    longitude DECIMAL(10,6),
    contributing_factor_vehicle1 VARCHAR(255),
    contributing_factor_vehicle2 VARCHAR(255),
    unique_key BIGINT NOT NULL PRIMARY KEY,
    vehicle_type_code_1 VARCHAR(255),
    vehicle_type_code_2 VARCHAR(255))
    COMPRESS YES;

/*db2 => grant all privileges on schema CSE532 to DB2ADMIN
DB20000I  The SQL command completed successfully.
In case if you encounter issue on dbeaver while checking if table is created or not 
*/